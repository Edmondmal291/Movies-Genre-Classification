```python
# import libaries
from bs4 import BeautifulSoup
from nltk import FreqDist
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from tkinter import filedialog as fd
from IPython.display import display
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
import pysrt
import pandas as pd
import numpy as np
import os
import matplotlib
import plotly.graph_objects as go


#import pygwalker as pyg
```


```python
# extract the movie name from the file path
movie_list = []
srt_file_paths = fd.askopenfilenames(title='Open files',initialdir='~/Documents/CSS6625/training_data/')
for file_path in srt_file_paths:
    print(file_path)
    file_name = os.path.basename(file_path)
    movie_name = os.path.splitext(file_name)[0]
    movie_list.append(movie_name)
    #print(movie_name)
print(movie_list)
```

    /home/emalone/Documents/CSS6625/training_data/An.Evening-Grym.srt
    /home/emalone/Documents/CSS6625/training_data/Anatomy.of.a.Scene-Grym.srt
    /home/emalone/Documents/CSS6625/training_data/Behind.the.Music-Grym.srt
    /home/emalone/Documents/CSS6625/training_data/Blade_1.srt
    /home/emalone/Documents/CSS6625/training_data/Bride.Of.Chucky.srt
    /home/emalone/Documents/CSS6625/training_data/Candyman.srt
    /home/emalone/Documents/CSS6625/training_data/Cold.Pursuit.srt
    /home/emalone/Documents/CSS6625/training_data/Demolition_Man.srt
    /home/emalone/Documents/CSS6625/training_data/Drag_Me_To_Hell.srt
    /home/emalone/Documents/CSS6625/training_data/EVIL-DEAD-RISE.srt
    /home/emalone/Documents/CSS6625/training_data/Freaky.srt
    /home/emalone/Documents/CSS6625/training_data/Halloween_II.srt
    /home/emalone/Documents/CSS6625/training_data/Haunted Mansion.srt
    /home/emalone/Documents/CSS6625/training_data/IndependenceDay.srt
    /home/emalone/Documents/CSS6625/training_data/Ip Man.srt
    /home/emalone/Documents/CSS6625/training_data/It.srt
    /home/emalone/Documents/CSS6625/training_data/JackReacher.srt
    /home/emalone/Documents/CSS6625/training_data/JohnWick.srt
    /home/emalone/Documents/CSS6625/training_data/Mr_and_Mrs_Smith.srt
    /home/emalone/Documents/CSS6625/training_data/Pet.Sematary.srt
    /home/emalone/Documents/CSS6625/training_data/Rush.Hour.srt
    /home/emalone/Documents/CSS6625/training_data/Saw.X.srt
    /home/emalone/Documents/CSS6625/training_data/Sinister.srt
    /home/emalone/Documents/CSS6625/training_data/The.Cabin.in.the.Woods.srt
    /home/emalone/Documents/CSS6625/training_data/The.Exorcist.srt
    /home/emalone/Documents/CSS6625/training_data/The.Notebook.srt
    /home/emalone/Documents/CSS6625/training_data/The.One.srt
    /home/emalone/Documents/CSS6625/training_data/The.Raid.Redemption.srt
    /home/emalone/Documents/CSS6625/training_data/TheDarkKnight2008.BrRip.srt
    /home/emalone/Documents/CSS6625/training_data/Titanic.srt
    /home/emalone/Documents/CSS6625/training_data/Violent.Night.srt
    /home/emalone/Documents/CSS6625/training_data/Wanted.srt
    ['An.Evening-Grym', 'Anatomy.of.a.Scene-Grym', 'Behind.the.Music-Grym', 'Blade_1', 'Bride.Of.Chucky', 'Candyman', 'Cold.Pursuit', 'Demolition_Man', 'Drag_Me_To_Hell', 'EVIL-DEAD-RISE', 'Freaky', 'Halloween_II', 'Haunted Mansion', 'IndependenceDay', 'Ip Man', 'It', 'JackReacher', 'JohnWick', 'Mr_and_Mrs_Smith', 'Pet.Sematary', 'Rush.Hour', 'Saw.X', 'Sinister', 'The.Cabin.in.the.Woods', 'The.Exorcist', 'The.Notebook', 'The.One', 'The.Raid.Redemption', 'TheDarkKnight2008.BrRip', 'Titanic', 'Violent.Night', 'Wanted']



```python
word_bank = ['god','help','kill','please','dead','love','sorry','beautiful','baby','father','bomb']
movie_data = []
movie_row = []
common_words = []
movie_counter = 0
cell_counter = 0


if(len(srt_file_paths) > 0):
    # Iterate over the tuple of file paths
    for file_path in srt_file_paths:
        #print(file_path)
        srt_file = pysrt.open(file_path)
        subs = srt_file
        # extract only the html tags and content from the raw srt file and print to screen.
        html_text_list = []
        html_tags_with_text = ""
        counter = 0
        srt_total_line_numebers = len(subs)
        while counter < srt_total_line_numebers:
            html_tags_with_text += subs[counter].text
            html_text_list.append(subs[counter].text)
            counter +=1
        # Put a space between each element to create a string 
        corpus_with_tags = ''.join(html_text_list)
        #print(corpus_with_tags)
        # Parse the text from in between the html tags in to memoryy
        soup = BeautifulSoup(corpus_with_tags, 'html.parser')
        corpus = soup.get_text().lower()
        #print(corpus)
        # Tokenizing the sentence into indvidual words.
        tokenize_words =  word_tokenize(corpus)
        #print(tokenize_words)
        
        #frequency_distribution = FreqDist(tokenize_words)
        # Filter out the stop words and place the filtered words into a seperate list.  
        filtered_list = []
        stop_words = set(stopwords.words("english"))
        for word in tokenize_words:
            if word.casefold() not in stop_words:
                filtered_list.append(word)
                if (word == ' kill' or word ==" Kill"):
                    print("found word {0}".format(word))
        #print(filtered_list)
        # Display the most frequent word that is contain in the list.
        frequency_distribution = FreqDist(filtered_list)
        # add movie name in the first element
        movie_row.append(movie_list[movie_counter])
        common_words = frequency_distribution.most_common(300)
        #len(common_words)
        print(len(common_words))
        missing_common_word_counter = 0
        for word in word_bank:
            #print("the common word is {0}".format(common_words))
            #for word in word_bank:
            for common_word in common_words:
                #print("the word bank is {0} and the common word is {1}".format(word,common_words))
                if (word == common_word[0]):
                    #print("found match#{0}".format(word)) 
                    cell_counter += 1
                    movie_row.append(common_word[1])
                    missing_common_word_counter = 0
                else:
                    # if the word is not located in the 
                    missing_common_word_counter += 1
                    if(missing_common_word_counter == len(common_words)):
                        movie_row.append(0)
            missing_common_word_counter = 0

        print(movie_row)
        movie_data.append(movie_row)
        movie_row = []
        print(movie_counter)
        movie_counter += 1
        cell_counter = 0
        # iterate over the words to create training data 
elif(len(srt_file_paths) == 0):
   print("select a file")
movie_counter = 0
```

    300
    ['An.Evening-Grym', 0, 0, 3, 0, 0, 8, 0, 0, 0, 0, 0]
    0
    147
    ['Anatomy.of.a.Scene-Grym', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    1
    300
    ['Behind.the.Music-Grym', 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0]
    2
    300
    ['Blade_1', 4, 4, 5, 4, 5, 0, 3, 0, 3, 0, 0]
    3
    300
    ['Bride.Of.Chucky', 10, 4, 7, 8, 11, 17, 0, 4, 3, 0, 0]
    4
    300
    ['Candyman', 5, 11, 4, 13, 0, 4, 4, 2, 11, 3, 0]
    5
    300
    ['Cold.Pursuit', 0, 10, 7, 6, 4, 7, 5, 0, 5, 7, 0]
    6
    300
    ['Demolition_Man', 3, 0, 11, 6, 0, 7, 8, 0, 0, 0, 0]
    7
    300
    ['Drag_Me_To_Hell', 22, 16, 0, 10, 14, 10, 7, 0, 8, 2, 0]
    8
    300
    ['EVIL-DEAD-RISE', 2, 8, 2, 5, 12, 4, 4, 0, 0, 3, 0]
    9
    300
    ['Freaky', 28, 23, 7, 18, 3, 19, 18, 0, 0, 0, 0]
    10
    300
    ['Halloween_II', 19, 22, 8, 53, 8, 12, 9, 2, 13, 0, 0]
    11
    300
    ['Haunted Mansion', 10, 21, 0, 0, 9, 6, 9, 0, 4, 12, 0]
    12
    300
    ['IndependenceDay', 22, 7, 4, 13, 0, 12, 9, 0, 11, 0, 0]
    13
    300
    ['Ip Man', 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0]
    14
    300
    ['It', 23, 30, 26, 13, 22, 14, 9, 0, 0, 7, 0]
    15
    300
    ['JackReacher', 0, 8, 12, 0, 4, 3, 4, 0, 0, 9, 0]
    16
    300
    ['JohnWick', 5, 0, 8, 2, 0, 3, 4, 0, 0, 1, 0]
    17
    300
    ['Mr_and_Mrs_Smith', 3, 0, 12, 3, 0, 8, 8, 0, 3, 0, 0]
    18
    300
    ['Pet.Sematary', 14, 4, 0, 0, 15, 5, 3, 0, 4, 3, 0]
    19
    300
    ['Rush.Hour', 5, 9, 7, 9, 0, 0, 11, 0, 5, 9, 7]
    20
    300
    ['Saw.X', 2, 8, 10, 12, 2, 0, 0, 0, 0, 8, 0]
    21
    300
    ['Sinister', 8, 4, 0, 0, 0, 0, 13, 0, 0, 0, 0]
    22
    300
    ['The.Cabin.in.the.Woods', 15, 5, 8, 9, 3, 0, 4, 0, 4, 2, 0]
    23
    300
    ['The.Exorcist', 18, 13, 0, 15, 3, 9, 9, 0, 0, 34, 0]
    24
    300
    ['The.Notebook', 6, 11, 0, 9, 0, 44, 14, 6, 6, 0, 0]
    25
    300
    ['The.One', 2, 3, 16, 0, 9, 0, 0, 0, 0, 0, 0]
    26
    300
    ['The.Raid.Redemption', 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0]
    27
    300
    ['TheDarkKnight2008.BrRip', 5, 6, 18, 9, 5, 6, 10, 0, 0, 0, 0]
    28
    300
    ['Titanic', 15, 18, 0, 24, 0, 11, 11, 0, 4, 0, 0]
    29
    300
    ['Violent.Night', 7, 8, 10, 3, 6, 5, 6, 3, 0, 0, 0]
    30
    300
    ['Wanted', 8, 0, 21, 7, 3, 3, 13, 0, 3, 24, 0]
    31


# Create Dataframe with movie_data from previous steps


```python
common_word_header = ['movie_name','god','help','kill','please','dead','love','sorry','beautiful','baby','father','bomb']
df = pd.DataFrame(movie_data, columns=common_word_header )
df["genre"]= ""
display(df)
```


```python
common_word_header = ['movie_name','god','help','kill','please','dead','love','sorry','beautiful','baby','father','bomb']
df = pd.DataFrame(movie_data, columns=common_word_header )
df["genre"]= ""
#display(df)
# Display graphs of explatory data 
```


```python
# Display graphs of explatory data 
df.plot(x="movie_name", y=['god','help','kill','please','dead','love','sorry','beautiful','baby','father','bomb'], kind= "bar")

df.plot.bar(stacked=True)

```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movie_name</th>
      <th>god</th>
      <th>help</th>
      <th>kill</th>
      <th>please</th>
      <th>dead</th>
      <th>love</th>
      <th>sorry</th>
      <th>beautiful</th>
      <th>baby</th>
      <th>father</th>
      <th>bomb</th>
      <th>genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>An.Evening-Grym</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>1</th>
      <td>Anatomy.of.a.Scene-Grym</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>2</th>
      <td>Behind.the.Music-Grym</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>3</th>
      <td>Blade_1</td>
      <td>4</td>
      <td>4</td>
      <td>5</td>
      <td>4</td>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bride.Of.Chucky</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>8</td>
      <td>11</td>
      <td>17</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>5</th>
      <td>Candyman</td>
      <td>5</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>0</td>
      <td>4</td>
      <td>4</td>
      <td>2</td>
      <td>11</td>
      <td>3</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>6</th>
      <td>Cold.Pursuit</td>
      <td>0</td>
      <td>10</td>
      <td>7</td>
      <td>6</td>
      <td>4</td>
      <td>7</td>
      <td>5</td>
      <td>0</td>
      <td>5</td>
      <td>7</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>7</th>
      <td>Demolition_Man</td>
      <td>3</td>
      <td>0</td>
      <td>11</td>
      <td>6</td>
      <td>0</td>
      <td>7</td>
      <td>8</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>8</th>
      <td>Drag_Me_To_Hell</td>
      <td>22</td>
      <td>16</td>
      <td>0</td>
      <td>10</td>
      <td>14</td>
      <td>10</td>
      <td>7</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>9</th>
      <td>EVIL-DEAD-RISE</td>
      <td>2</td>
      <td>8</td>
      <td>2</td>
      <td>5</td>
      <td>12</td>
      <td>4</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>10</th>
      <td>Freaky</td>
      <td>28</td>
      <td>23</td>
      <td>7</td>
      <td>18</td>
      <td>3</td>
      <td>19</td>
      <td>18</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>11</th>
      <td>Halloween_II</td>
      <td>19</td>
      <td>22</td>
      <td>8</td>
      <td>53</td>
      <td>8</td>
      <td>12</td>
      <td>9</td>
      <td>2</td>
      <td>13</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>12</th>
      <td>Haunted Mansion</td>
      <td>10</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>6</td>
      <td>9</td>
      <td>0</td>
      <td>4</td>
      <td>12</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>13</th>
      <td>IndependenceDay</td>
      <td>22</td>
      <td>7</td>
      <td>4</td>
      <td>13</td>
      <td>0</td>
      <td>12</td>
      <td>9</td>
      <td>0</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>14</th>
      <td>Ip Man</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>15</th>
      <td>It</td>
      <td>23</td>
      <td>30</td>
      <td>26</td>
      <td>13</td>
      <td>22</td>
      <td>14</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>16</th>
      <td>JackReacher</td>
      <td>0</td>
      <td>8</td>
      <td>12</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>17</th>
      <td>JohnWick</td>
      <td>5</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>18</th>
      <td>Mr_and_Mrs_Smith</td>
      <td>3</td>
      <td>0</td>
      <td>12</td>
      <td>3</td>
      <td>0</td>
      <td>8</td>
      <td>8</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>19</th>
      <td>Pet.Sematary</td>
      <td>14</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>15</td>
      <td>5</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>20</th>
      <td>Rush.Hour</td>
      <td>5</td>
      <td>9</td>
      <td>7</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>11</td>
      <td>0</td>
      <td>5</td>
      <td>9</td>
      <td>7</td>
      <td></td>
    </tr>
    <tr>
      <th>21</th>
      <td>Saw.X</td>
      <td>2</td>
      <td>8</td>
      <td>10</td>
      <td>12</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>22</th>
      <td>Sinister</td>
      <td>8</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>23</th>
      <td>The.Cabin.in.the.Woods</td>
      <td>15</td>
      <td>5</td>
      <td>8</td>
      <td>9</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>2</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>24</th>
      <td>The.Exorcist</td>
      <td>18</td>
      <td>13</td>
      <td>0</td>
      <td>15</td>
      <td>3</td>
      <td>9</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>25</th>
      <td>The.Notebook</td>
      <td>6</td>
      <td>11</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td>44</td>
      <td>14</td>
      <td>6</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>26</th>
      <td>The.One</td>
      <td>2</td>
      <td>3</td>
      <td>16</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>27</th>
      <td>The.Raid.Redemption</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>28</th>
      <td>TheDarkKnight2008.BrRip</td>
      <td>5</td>
      <td>6</td>
      <td>18</td>
      <td>9</td>
      <td>5</td>
      <td>6</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>29</th>
      <td>Titanic</td>
      <td>15</td>
      <td>18</td>
      <td>0</td>
      <td>24</td>
      <td>0</td>
      <td>11</td>
      <td>11</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>30</th>
      <td>Violent.Night</td>
      <td>7</td>
      <td>8</td>
      <td>10</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>6</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
    </tr>
    <tr>
      <th>31</th>
      <td>Wanted</td>
      <td>8</td>
      <td>0</td>
      <td>21</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>13</td>
      <td>0</td>
      <td>3</td>
      <td>24</td>
      <td>0</td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>





    <Axes: >




    
![png](output_6_2.png)
    



    
![png](output_6_3.png)
    


# Display Interactive Grouped bar chart


```python
bar_objects = []
for common_word in word_bank:
    #bar_objects.append(go.Bar(name=common_word, x=word_bank, y=df[common_word].tolist()))
    fig = go.Figure([go.Bar(x=df['movie_name'].tolist(),y=df[common_word].tolist())])
    #fig.update_layout(title_text=''
    fig.show()
    
#print(bar_objects)

#fig = go.Figure(data=bar_objects)
#fig.update_layout(barmode='group')
#fig.show()



```

# Export dataframe to csv to manuely label the data.


```python
df.to_csv('/home/emalone/Documents/CSS6625/training_set/training_data.csv')
```

# Naviagte to the recent expoted csv and label the empty genre column with the appropiate values (Action, Horror and Romance) 


```python
# import training data
training_data_path=fd.askopenfilename(title='Open files',initialdir='~/Documents/CSS6625/training_set')
print(training_data_path)
train_data = pd.read_csv(training_data_path)
train_data.style
```

    /home/emalone/Documents/CSS6625/training_set/training_data.csv





<style type="text/css">
</style>
<table id="T_ef603">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th id="T_ef603_level0_col0" class="col_heading level0 col0" >Unnamed: 0</th>
      <th id="T_ef603_level0_col1" class="col_heading level0 col1" >movie_name</th>
      <th id="T_ef603_level0_col2" class="col_heading level0 col2" >god</th>
      <th id="T_ef603_level0_col3" class="col_heading level0 col3" >help</th>
      <th id="T_ef603_level0_col4" class="col_heading level0 col4" >kill</th>
      <th id="T_ef603_level0_col5" class="col_heading level0 col5" >please</th>
      <th id="T_ef603_level0_col6" class="col_heading level0 col6" >dead</th>
      <th id="T_ef603_level0_col7" class="col_heading level0 col7" >love</th>
      <th id="T_ef603_level0_col8" class="col_heading level0 col8" >sorry</th>
      <th id="T_ef603_level0_col9" class="col_heading level0 col9" >beautiful</th>
      <th id="T_ef603_level0_col10" class="col_heading level0 col10" >baby</th>
      <th id="T_ef603_level0_col11" class="col_heading level0 col11" >father</th>
      <th id="T_ef603_level0_col12" class="col_heading level0 col12" >bomb</th>
      <th id="T_ef603_level0_col13" class="col_heading level0 col13" >genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_ef603_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_ef603_row0_col0" class="data row0 col0" >0</td>
      <td id="T_ef603_row0_col1" class="data row0 col1" >An.Evening-Grym</td>
      <td id="T_ef603_row0_col2" class="data row0 col2" >0</td>
      <td id="T_ef603_row0_col3" class="data row0 col3" >0</td>
      <td id="T_ef603_row0_col4" class="data row0 col4" >3</td>
      <td id="T_ef603_row0_col5" class="data row0 col5" >0</td>
      <td id="T_ef603_row0_col6" class="data row0 col6" >0</td>
      <td id="T_ef603_row0_col7" class="data row0 col7" >8</td>
      <td id="T_ef603_row0_col8" class="data row0 col8" >0</td>
      <td id="T_ef603_row0_col9" class="data row0 col9" >0</td>
      <td id="T_ef603_row0_col10" class="data row0 col10" >0</td>
      <td id="T_ef603_row0_col11" class="data row0 col11" >0</td>
      <td id="T_ef603_row0_col12" class="data row0 col12" >0</td>
      <td id="T_ef603_row0_col13" class="data row0 col13" >Romance</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_ef603_row1_col0" class="data row1 col0" >1</td>
      <td id="T_ef603_row1_col1" class="data row1 col1" >Anatomy.of.a.Scene-Grym</td>
      <td id="T_ef603_row1_col2" class="data row1 col2" >0</td>
      <td id="T_ef603_row1_col3" class="data row1 col3" >0</td>
      <td id="T_ef603_row1_col4" class="data row1 col4" >0</td>
      <td id="T_ef603_row1_col5" class="data row1 col5" >0</td>
      <td id="T_ef603_row1_col6" class="data row1 col6" >0</td>
      <td id="T_ef603_row1_col7" class="data row1 col7" >0</td>
      <td id="T_ef603_row1_col8" class="data row1 col8" >0</td>
      <td id="T_ef603_row1_col9" class="data row1 col9" >0</td>
      <td id="T_ef603_row1_col10" class="data row1 col10" >0</td>
      <td id="T_ef603_row1_col11" class="data row1 col11" >0</td>
      <td id="T_ef603_row1_col12" class="data row1 col12" >0</td>
      <td id="T_ef603_row1_col13" class="data row1 col13" >Romance</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_ef603_row2_col0" class="data row2 col0" >2</td>
      <td id="T_ef603_row2_col1" class="data row2 col1" >Behind.the.Music-Grym</td>
      <td id="T_ef603_row2_col2" class="data row2 col2" >0</td>
      <td id="T_ef603_row2_col3" class="data row2 col3" >1</td>
      <td id="T_ef603_row2_col4" class="data row2 col4" >0</td>
      <td id="T_ef603_row2_col5" class="data row2 col5" >0</td>
      <td id="T_ef603_row2_col6" class="data row2 col6" >0</td>
      <td id="T_ef603_row2_col7" class="data row2 col7" >2</td>
      <td id="T_ef603_row2_col8" class="data row2 col8" >0</td>
      <td id="T_ef603_row2_col9" class="data row2 col9" >0</td>
      <td id="T_ef603_row2_col10" class="data row2 col10" >0</td>
      <td id="T_ef603_row2_col11" class="data row2 col11" >0</td>
      <td id="T_ef603_row2_col12" class="data row2 col12" >0</td>
      <td id="T_ef603_row2_col13" class="data row2 col13" >Romance</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_ef603_row3_col0" class="data row3 col0" >3</td>
      <td id="T_ef603_row3_col1" class="data row3 col1" >Blade_1</td>
      <td id="T_ef603_row3_col2" class="data row3 col2" >4</td>
      <td id="T_ef603_row3_col3" class="data row3 col3" >4</td>
      <td id="T_ef603_row3_col4" class="data row3 col4" >5</td>
      <td id="T_ef603_row3_col5" class="data row3 col5" >4</td>
      <td id="T_ef603_row3_col6" class="data row3 col6" >5</td>
      <td id="T_ef603_row3_col7" class="data row3 col7" >0</td>
      <td id="T_ef603_row3_col8" class="data row3 col8" >3</td>
      <td id="T_ef603_row3_col9" class="data row3 col9" >0</td>
      <td id="T_ef603_row3_col10" class="data row3 col10" >3</td>
      <td id="T_ef603_row3_col11" class="data row3 col11" >0</td>
      <td id="T_ef603_row3_col12" class="data row3 col12" >0</td>
      <td id="T_ef603_row3_col13" class="data row3 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_ef603_row4_col0" class="data row4 col0" >4</td>
      <td id="T_ef603_row4_col1" class="data row4 col1" >Bride.Of.Chucky</td>
      <td id="T_ef603_row4_col2" class="data row4 col2" >10</td>
      <td id="T_ef603_row4_col3" class="data row4 col3" >4</td>
      <td id="T_ef603_row4_col4" class="data row4 col4" >7</td>
      <td id="T_ef603_row4_col5" class="data row4 col5" >8</td>
      <td id="T_ef603_row4_col6" class="data row4 col6" >11</td>
      <td id="T_ef603_row4_col7" class="data row4 col7" >17</td>
      <td id="T_ef603_row4_col8" class="data row4 col8" >0</td>
      <td id="T_ef603_row4_col9" class="data row4 col9" >4</td>
      <td id="T_ef603_row4_col10" class="data row4 col10" >3</td>
      <td id="T_ef603_row4_col11" class="data row4 col11" >0</td>
      <td id="T_ef603_row4_col12" class="data row4 col12" >0</td>
      <td id="T_ef603_row4_col13" class="data row4 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_ef603_row5_col0" class="data row5 col0" >5</td>
      <td id="T_ef603_row5_col1" class="data row5 col1" >Candyman</td>
      <td id="T_ef603_row5_col2" class="data row5 col2" >5</td>
      <td id="T_ef603_row5_col3" class="data row5 col3" >11</td>
      <td id="T_ef603_row5_col4" class="data row5 col4" >4</td>
      <td id="T_ef603_row5_col5" class="data row5 col5" >13</td>
      <td id="T_ef603_row5_col6" class="data row5 col6" >0</td>
      <td id="T_ef603_row5_col7" class="data row5 col7" >4</td>
      <td id="T_ef603_row5_col8" class="data row5 col8" >4</td>
      <td id="T_ef603_row5_col9" class="data row5 col9" >2</td>
      <td id="T_ef603_row5_col10" class="data row5 col10" >11</td>
      <td id="T_ef603_row5_col11" class="data row5 col11" >3</td>
      <td id="T_ef603_row5_col12" class="data row5 col12" >0</td>
      <td id="T_ef603_row5_col13" class="data row5 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_ef603_row6_col0" class="data row6 col0" >6</td>
      <td id="T_ef603_row6_col1" class="data row6 col1" >Cold.Pursuit</td>
      <td id="T_ef603_row6_col2" class="data row6 col2" >0</td>
      <td id="T_ef603_row6_col3" class="data row6 col3" >10</td>
      <td id="T_ef603_row6_col4" class="data row6 col4" >7</td>
      <td id="T_ef603_row6_col5" class="data row6 col5" >6</td>
      <td id="T_ef603_row6_col6" class="data row6 col6" >4</td>
      <td id="T_ef603_row6_col7" class="data row6 col7" >7</td>
      <td id="T_ef603_row6_col8" class="data row6 col8" >5</td>
      <td id="T_ef603_row6_col9" class="data row6 col9" >0</td>
      <td id="T_ef603_row6_col10" class="data row6 col10" >5</td>
      <td id="T_ef603_row6_col11" class="data row6 col11" >7</td>
      <td id="T_ef603_row6_col12" class="data row6 col12" >0</td>
      <td id="T_ef603_row6_col13" class="data row6 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_ef603_row7_col0" class="data row7 col0" >7</td>
      <td id="T_ef603_row7_col1" class="data row7 col1" >Demolition_Man</td>
      <td id="T_ef603_row7_col2" class="data row7 col2" >3</td>
      <td id="T_ef603_row7_col3" class="data row7 col3" >0</td>
      <td id="T_ef603_row7_col4" class="data row7 col4" >11</td>
      <td id="T_ef603_row7_col5" class="data row7 col5" >6</td>
      <td id="T_ef603_row7_col6" class="data row7 col6" >0</td>
      <td id="T_ef603_row7_col7" class="data row7 col7" >7</td>
      <td id="T_ef603_row7_col8" class="data row7 col8" >8</td>
      <td id="T_ef603_row7_col9" class="data row7 col9" >0</td>
      <td id="T_ef603_row7_col10" class="data row7 col10" >0</td>
      <td id="T_ef603_row7_col11" class="data row7 col11" >0</td>
      <td id="T_ef603_row7_col12" class="data row7 col12" >0</td>
      <td id="T_ef603_row7_col13" class="data row7 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_ef603_row8_col0" class="data row8 col0" >8</td>
      <td id="T_ef603_row8_col1" class="data row8 col1" >Drag_Me_To_Hell</td>
      <td id="T_ef603_row8_col2" class="data row8 col2" >22</td>
      <td id="T_ef603_row8_col3" class="data row8 col3" >16</td>
      <td id="T_ef603_row8_col4" class="data row8 col4" >0</td>
      <td id="T_ef603_row8_col5" class="data row8 col5" >10</td>
      <td id="T_ef603_row8_col6" class="data row8 col6" >14</td>
      <td id="T_ef603_row8_col7" class="data row8 col7" >10</td>
      <td id="T_ef603_row8_col8" class="data row8 col8" >7</td>
      <td id="T_ef603_row8_col9" class="data row8 col9" >0</td>
      <td id="T_ef603_row8_col10" class="data row8 col10" >8</td>
      <td id="T_ef603_row8_col11" class="data row8 col11" >2</td>
      <td id="T_ef603_row8_col12" class="data row8 col12" >0</td>
      <td id="T_ef603_row8_col13" class="data row8 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_ef603_row9_col0" class="data row9 col0" >9</td>
      <td id="T_ef603_row9_col1" class="data row9 col1" >EVIL-DEAD-RISE</td>
      <td id="T_ef603_row9_col2" class="data row9 col2" >2</td>
      <td id="T_ef603_row9_col3" class="data row9 col3" >8</td>
      <td id="T_ef603_row9_col4" class="data row9 col4" >2</td>
      <td id="T_ef603_row9_col5" class="data row9 col5" >5</td>
      <td id="T_ef603_row9_col6" class="data row9 col6" >12</td>
      <td id="T_ef603_row9_col7" class="data row9 col7" >4</td>
      <td id="T_ef603_row9_col8" class="data row9 col8" >4</td>
      <td id="T_ef603_row9_col9" class="data row9 col9" >0</td>
      <td id="T_ef603_row9_col10" class="data row9 col10" >0</td>
      <td id="T_ef603_row9_col11" class="data row9 col11" >3</td>
      <td id="T_ef603_row9_col12" class="data row9 col12" >0</td>
      <td id="T_ef603_row9_col13" class="data row9 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row10" class="row_heading level0 row10" >10</th>
      <td id="T_ef603_row10_col0" class="data row10 col0" >10</td>
      <td id="T_ef603_row10_col1" class="data row10 col1" >Freaky</td>
      <td id="T_ef603_row10_col2" class="data row10 col2" >28</td>
      <td id="T_ef603_row10_col3" class="data row10 col3" >23</td>
      <td id="T_ef603_row10_col4" class="data row10 col4" >7</td>
      <td id="T_ef603_row10_col5" class="data row10 col5" >18</td>
      <td id="T_ef603_row10_col6" class="data row10 col6" >3</td>
      <td id="T_ef603_row10_col7" class="data row10 col7" >19</td>
      <td id="T_ef603_row10_col8" class="data row10 col8" >18</td>
      <td id="T_ef603_row10_col9" class="data row10 col9" >0</td>
      <td id="T_ef603_row10_col10" class="data row10 col10" >0</td>
      <td id="T_ef603_row10_col11" class="data row10 col11" >0</td>
      <td id="T_ef603_row10_col12" class="data row10 col12" >0</td>
      <td id="T_ef603_row10_col13" class="data row10 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row11" class="row_heading level0 row11" >11</th>
      <td id="T_ef603_row11_col0" class="data row11 col0" >11</td>
      <td id="T_ef603_row11_col1" class="data row11 col1" >Halloween_II</td>
      <td id="T_ef603_row11_col2" class="data row11 col2" >19</td>
      <td id="T_ef603_row11_col3" class="data row11 col3" >22</td>
      <td id="T_ef603_row11_col4" class="data row11 col4" >8</td>
      <td id="T_ef603_row11_col5" class="data row11 col5" >53</td>
      <td id="T_ef603_row11_col6" class="data row11 col6" >8</td>
      <td id="T_ef603_row11_col7" class="data row11 col7" >12</td>
      <td id="T_ef603_row11_col8" class="data row11 col8" >9</td>
      <td id="T_ef603_row11_col9" class="data row11 col9" >2</td>
      <td id="T_ef603_row11_col10" class="data row11 col10" >13</td>
      <td id="T_ef603_row11_col11" class="data row11 col11" >0</td>
      <td id="T_ef603_row11_col12" class="data row11 col12" >0</td>
      <td id="T_ef603_row11_col13" class="data row11 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row12" class="row_heading level0 row12" >12</th>
      <td id="T_ef603_row12_col0" class="data row12 col0" >12</td>
      <td id="T_ef603_row12_col1" class="data row12 col1" >Haunted Mansion</td>
      <td id="T_ef603_row12_col2" class="data row12 col2" >10</td>
      <td id="T_ef603_row12_col3" class="data row12 col3" >21</td>
      <td id="T_ef603_row12_col4" class="data row12 col4" >0</td>
      <td id="T_ef603_row12_col5" class="data row12 col5" >0</td>
      <td id="T_ef603_row12_col6" class="data row12 col6" >9</td>
      <td id="T_ef603_row12_col7" class="data row12 col7" >6</td>
      <td id="T_ef603_row12_col8" class="data row12 col8" >9</td>
      <td id="T_ef603_row12_col9" class="data row12 col9" >0</td>
      <td id="T_ef603_row12_col10" class="data row12 col10" >4</td>
      <td id="T_ef603_row12_col11" class="data row12 col11" >12</td>
      <td id="T_ef603_row12_col12" class="data row12 col12" >0</td>
      <td id="T_ef603_row12_col13" class="data row12 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row13" class="row_heading level0 row13" >13</th>
      <td id="T_ef603_row13_col0" class="data row13 col0" >13</td>
      <td id="T_ef603_row13_col1" class="data row13 col1" >IndependenceDay</td>
      <td id="T_ef603_row13_col2" class="data row13 col2" >22</td>
      <td id="T_ef603_row13_col3" class="data row13 col3" >7</td>
      <td id="T_ef603_row13_col4" class="data row13 col4" >4</td>
      <td id="T_ef603_row13_col5" class="data row13 col5" >13</td>
      <td id="T_ef603_row13_col6" class="data row13 col6" >0</td>
      <td id="T_ef603_row13_col7" class="data row13 col7" >12</td>
      <td id="T_ef603_row13_col8" class="data row13 col8" >9</td>
      <td id="T_ef603_row13_col9" class="data row13 col9" >0</td>
      <td id="T_ef603_row13_col10" class="data row13 col10" >11</td>
      <td id="T_ef603_row13_col11" class="data row13 col11" >0</td>
      <td id="T_ef603_row13_col12" class="data row13 col12" >0</td>
      <td id="T_ef603_row13_col13" class="data row13 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row14" class="row_heading level0 row14" >14</th>
      <td id="T_ef603_row14_col0" class="data row14 col0" >14</td>
      <td id="T_ef603_row14_col1" class="data row14 col1" >Ip Man</td>
      <td id="T_ef603_row14_col2" class="data row14 col2" >0</td>
      <td id="T_ef603_row14_col3" class="data row14 col3" >0</td>
      <td id="T_ef603_row14_col4" class="data row14 col4" >0</td>
      <td id="T_ef603_row14_col5" class="data row14 col5" >0</td>
      <td id="T_ef603_row14_col6" class="data row14 col6" >1</td>
      <td id="T_ef603_row14_col7" class="data row14 col7" >0</td>
      <td id="T_ef603_row14_col8" class="data row14 col8" >2</td>
      <td id="T_ef603_row14_col9" class="data row14 col9" >0</td>
      <td id="T_ef603_row14_col10" class="data row14 col10" >0</td>
      <td id="T_ef603_row14_col11" class="data row14 col11" >0</td>
      <td id="T_ef603_row14_col12" class="data row14 col12" >0</td>
      <td id="T_ef603_row14_col13" class="data row14 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row15" class="row_heading level0 row15" >15</th>
      <td id="T_ef603_row15_col0" class="data row15 col0" >15</td>
      <td id="T_ef603_row15_col1" class="data row15 col1" >It</td>
      <td id="T_ef603_row15_col2" class="data row15 col2" >23</td>
      <td id="T_ef603_row15_col3" class="data row15 col3" >30</td>
      <td id="T_ef603_row15_col4" class="data row15 col4" >26</td>
      <td id="T_ef603_row15_col5" class="data row15 col5" >13</td>
      <td id="T_ef603_row15_col6" class="data row15 col6" >22</td>
      <td id="T_ef603_row15_col7" class="data row15 col7" >14</td>
      <td id="T_ef603_row15_col8" class="data row15 col8" >9</td>
      <td id="T_ef603_row15_col9" class="data row15 col9" >0</td>
      <td id="T_ef603_row15_col10" class="data row15 col10" >0</td>
      <td id="T_ef603_row15_col11" class="data row15 col11" >7</td>
      <td id="T_ef603_row15_col12" class="data row15 col12" >0</td>
      <td id="T_ef603_row15_col13" class="data row15 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row16" class="row_heading level0 row16" >16</th>
      <td id="T_ef603_row16_col0" class="data row16 col0" >16</td>
      <td id="T_ef603_row16_col1" class="data row16 col1" >JackReacher</td>
      <td id="T_ef603_row16_col2" class="data row16 col2" >0</td>
      <td id="T_ef603_row16_col3" class="data row16 col3" >8</td>
      <td id="T_ef603_row16_col4" class="data row16 col4" >12</td>
      <td id="T_ef603_row16_col5" class="data row16 col5" >0</td>
      <td id="T_ef603_row16_col6" class="data row16 col6" >4</td>
      <td id="T_ef603_row16_col7" class="data row16 col7" >3</td>
      <td id="T_ef603_row16_col8" class="data row16 col8" >4</td>
      <td id="T_ef603_row16_col9" class="data row16 col9" >0</td>
      <td id="T_ef603_row16_col10" class="data row16 col10" >0</td>
      <td id="T_ef603_row16_col11" class="data row16 col11" >9</td>
      <td id="T_ef603_row16_col12" class="data row16 col12" >0</td>
      <td id="T_ef603_row16_col13" class="data row16 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row17" class="row_heading level0 row17" >17</th>
      <td id="T_ef603_row17_col0" class="data row17 col0" >17</td>
      <td id="T_ef603_row17_col1" class="data row17 col1" >JohnWick</td>
      <td id="T_ef603_row17_col2" class="data row17 col2" >5</td>
      <td id="T_ef603_row17_col3" class="data row17 col3" >0</td>
      <td id="T_ef603_row17_col4" class="data row17 col4" >8</td>
      <td id="T_ef603_row17_col5" class="data row17 col5" >2</td>
      <td id="T_ef603_row17_col6" class="data row17 col6" >0</td>
      <td id="T_ef603_row17_col7" class="data row17 col7" >3</td>
      <td id="T_ef603_row17_col8" class="data row17 col8" >4</td>
      <td id="T_ef603_row17_col9" class="data row17 col9" >0</td>
      <td id="T_ef603_row17_col10" class="data row17 col10" >0</td>
      <td id="T_ef603_row17_col11" class="data row17 col11" >1</td>
      <td id="T_ef603_row17_col12" class="data row17 col12" >0</td>
      <td id="T_ef603_row17_col13" class="data row17 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row18" class="row_heading level0 row18" >18</th>
      <td id="T_ef603_row18_col0" class="data row18 col0" >18</td>
      <td id="T_ef603_row18_col1" class="data row18 col1" >Mr_and_Mrs_Smith</td>
      <td id="T_ef603_row18_col2" class="data row18 col2" >3</td>
      <td id="T_ef603_row18_col3" class="data row18 col3" >0</td>
      <td id="T_ef603_row18_col4" class="data row18 col4" >12</td>
      <td id="T_ef603_row18_col5" class="data row18 col5" >3</td>
      <td id="T_ef603_row18_col6" class="data row18 col6" >0</td>
      <td id="T_ef603_row18_col7" class="data row18 col7" >8</td>
      <td id="T_ef603_row18_col8" class="data row18 col8" >8</td>
      <td id="T_ef603_row18_col9" class="data row18 col9" >0</td>
      <td id="T_ef603_row18_col10" class="data row18 col10" >3</td>
      <td id="T_ef603_row18_col11" class="data row18 col11" >0</td>
      <td id="T_ef603_row18_col12" class="data row18 col12" >0</td>
      <td id="T_ef603_row18_col13" class="data row18 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row19" class="row_heading level0 row19" >19</th>
      <td id="T_ef603_row19_col0" class="data row19 col0" >19</td>
      <td id="T_ef603_row19_col1" class="data row19 col1" >Pet.Sematary</td>
      <td id="T_ef603_row19_col2" class="data row19 col2" >14</td>
      <td id="T_ef603_row19_col3" class="data row19 col3" >4</td>
      <td id="T_ef603_row19_col4" class="data row19 col4" >0</td>
      <td id="T_ef603_row19_col5" class="data row19 col5" >0</td>
      <td id="T_ef603_row19_col6" class="data row19 col6" >15</td>
      <td id="T_ef603_row19_col7" class="data row19 col7" >5</td>
      <td id="T_ef603_row19_col8" class="data row19 col8" >3</td>
      <td id="T_ef603_row19_col9" class="data row19 col9" >0</td>
      <td id="T_ef603_row19_col10" class="data row19 col10" >4</td>
      <td id="T_ef603_row19_col11" class="data row19 col11" >3</td>
      <td id="T_ef603_row19_col12" class="data row19 col12" >0</td>
      <td id="T_ef603_row19_col13" class="data row19 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row20" class="row_heading level0 row20" >20</th>
      <td id="T_ef603_row20_col0" class="data row20 col0" >20</td>
      <td id="T_ef603_row20_col1" class="data row20 col1" >Rush.Hour</td>
      <td id="T_ef603_row20_col2" class="data row20 col2" >5</td>
      <td id="T_ef603_row20_col3" class="data row20 col3" >9</td>
      <td id="T_ef603_row20_col4" class="data row20 col4" >7</td>
      <td id="T_ef603_row20_col5" class="data row20 col5" >9</td>
      <td id="T_ef603_row20_col6" class="data row20 col6" >0</td>
      <td id="T_ef603_row20_col7" class="data row20 col7" >0</td>
      <td id="T_ef603_row20_col8" class="data row20 col8" >11</td>
      <td id="T_ef603_row20_col9" class="data row20 col9" >0</td>
      <td id="T_ef603_row20_col10" class="data row20 col10" >5</td>
      <td id="T_ef603_row20_col11" class="data row20 col11" >9</td>
      <td id="T_ef603_row20_col12" class="data row20 col12" >7</td>
      <td id="T_ef603_row20_col13" class="data row20 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row21" class="row_heading level0 row21" >21</th>
      <td id="T_ef603_row21_col0" class="data row21 col0" >21</td>
      <td id="T_ef603_row21_col1" class="data row21 col1" >Saw.X</td>
      <td id="T_ef603_row21_col2" class="data row21 col2" >2</td>
      <td id="T_ef603_row21_col3" class="data row21 col3" >8</td>
      <td id="T_ef603_row21_col4" class="data row21 col4" >10</td>
      <td id="T_ef603_row21_col5" class="data row21 col5" >12</td>
      <td id="T_ef603_row21_col6" class="data row21 col6" >2</td>
      <td id="T_ef603_row21_col7" class="data row21 col7" >0</td>
      <td id="T_ef603_row21_col8" class="data row21 col8" >0</td>
      <td id="T_ef603_row21_col9" class="data row21 col9" >0</td>
      <td id="T_ef603_row21_col10" class="data row21 col10" >0</td>
      <td id="T_ef603_row21_col11" class="data row21 col11" >8</td>
      <td id="T_ef603_row21_col12" class="data row21 col12" >0</td>
      <td id="T_ef603_row21_col13" class="data row21 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row22" class="row_heading level0 row22" >22</th>
      <td id="T_ef603_row22_col0" class="data row22 col0" >22</td>
      <td id="T_ef603_row22_col1" class="data row22 col1" >Sinister</td>
      <td id="T_ef603_row22_col2" class="data row22 col2" >8</td>
      <td id="T_ef603_row22_col3" class="data row22 col3" >4</td>
      <td id="T_ef603_row22_col4" class="data row22 col4" >0</td>
      <td id="T_ef603_row22_col5" class="data row22 col5" >0</td>
      <td id="T_ef603_row22_col6" class="data row22 col6" >0</td>
      <td id="T_ef603_row22_col7" class="data row22 col7" >0</td>
      <td id="T_ef603_row22_col8" class="data row22 col8" >13</td>
      <td id="T_ef603_row22_col9" class="data row22 col9" >0</td>
      <td id="T_ef603_row22_col10" class="data row22 col10" >0</td>
      <td id="T_ef603_row22_col11" class="data row22 col11" >0</td>
      <td id="T_ef603_row22_col12" class="data row22 col12" >0</td>
      <td id="T_ef603_row22_col13" class="data row22 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row23" class="row_heading level0 row23" >23</th>
      <td id="T_ef603_row23_col0" class="data row23 col0" >23</td>
      <td id="T_ef603_row23_col1" class="data row23 col1" >The.Cabin.in.the.Woods</td>
      <td id="T_ef603_row23_col2" class="data row23 col2" >15</td>
      <td id="T_ef603_row23_col3" class="data row23 col3" >5</td>
      <td id="T_ef603_row23_col4" class="data row23 col4" >8</td>
      <td id="T_ef603_row23_col5" class="data row23 col5" >9</td>
      <td id="T_ef603_row23_col6" class="data row23 col6" >3</td>
      <td id="T_ef603_row23_col7" class="data row23 col7" >0</td>
      <td id="T_ef603_row23_col8" class="data row23 col8" >4</td>
      <td id="T_ef603_row23_col9" class="data row23 col9" >0</td>
      <td id="T_ef603_row23_col10" class="data row23 col10" >4</td>
      <td id="T_ef603_row23_col11" class="data row23 col11" >2</td>
      <td id="T_ef603_row23_col12" class="data row23 col12" >0</td>
      <td id="T_ef603_row23_col13" class="data row23 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row24" class="row_heading level0 row24" >24</th>
      <td id="T_ef603_row24_col0" class="data row24 col0" >24</td>
      <td id="T_ef603_row24_col1" class="data row24 col1" >The.Exorcist</td>
      <td id="T_ef603_row24_col2" class="data row24 col2" >18</td>
      <td id="T_ef603_row24_col3" class="data row24 col3" >13</td>
      <td id="T_ef603_row24_col4" class="data row24 col4" >0</td>
      <td id="T_ef603_row24_col5" class="data row24 col5" >15</td>
      <td id="T_ef603_row24_col6" class="data row24 col6" >3</td>
      <td id="T_ef603_row24_col7" class="data row24 col7" >9</td>
      <td id="T_ef603_row24_col8" class="data row24 col8" >9</td>
      <td id="T_ef603_row24_col9" class="data row24 col9" >0</td>
      <td id="T_ef603_row24_col10" class="data row24 col10" >0</td>
      <td id="T_ef603_row24_col11" class="data row24 col11" >34</td>
      <td id="T_ef603_row24_col12" class="data row24 col12" >0</td>
      <td id="T_ef603_row24_col13" class="data row24 col13" >Horror</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row25" class="row_heading level0 row25" >25</th>
      <td id="T_ef603_row25_col0" class="data row25 col0" >25</td>
      <td id="T_ef603_row25_col1" class="data row25 col1" >The.Notebook</td>
      <td id="T_ef603_row25_col2" class="data row25 col2" >6</td>
      <td id="T_ef603_row25_col3" class="data row25 col3" >11</td>
      <td id="T_ef603_row25_col4" class="data row25 col4" >0</td>
      <td id="T_ef603_row25_col5" class="data row25 col5" >9</td>
      <td id="T_ef603_row25_col6" class="data row25 col6" >0</td>
      <td id="T_ef603_row25_col7" class="data row25 col7" >44</td>
      <td id="T_ef603_row25_col8" class="data row25 col8" >14</td>
      <td id="T_ef603_row25_col9" class="data row25 col9" >6</td>
      <td id="T_ef603_row25_col10" class="data row25 col10" >6</td>
      <td id="T_ef603_row25_col11" class="data row25 col11" >0</td>
      <td id="T_ef603_row25_col12" class="data row25 col12" >0</td>
      <td id="T_ef603_row25_col13" class="data row25 col13" >Romance</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row26" class="row_heading level0 row26" >26</th>
      <td id="T_ef603_row26_col0" class="data row26 col0" >26</td>
      <td id="T_ef603_row26_col1" class="data row26 col1" >The.One</td>
      <td id="T_ef603_row26_col2" class="data row26 col2" >2</td>
      <td id="T_ef603_row26_col3" class="data row26 col3" >3</td>
      <td id="T_ef603_row26_col4" class="data row26 col4" >16</td>
      <td id="T_ef603_row26_col5" class="data row26 col5" >0</td>
      <td id="T_ef603_row26_col6" class="data row26 col6" >9</td>
      <td id="T_ef603_row26_col7" class="data row26 col7" >0</td>
      <td id="T_ef603_row26_col8" class="data row26 col8" >0</td>
      <td id="T_ef603_row26_col9" class="data row26 col9" >0</td>
      <td id="T_ef603_row26_col10" class="data row26 col10" >0</td>
      <td id="T_ef603_row26_col11" class="data row26 col11" >0</td>
      <td id="T_ef603_row26_col12" class="data row26 col12" >0</td>
      <td id="T_ef603_row26_col13" class="data row26 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row27" class="row_heading level0 row27" >27</th>
      <td id="T_ef603_row27_col0" class="data row27 col0" >27</td>
      <td id="T_ef603_row27_col1" class="data row27 col1" >The.Raid.Redemption</td>
      <td id="T_ef603_row27_col2" class="data row27 col2" >0</td>
      <td id="T_ef603_row27_col3" class="data row27 col3" >0</td>
      <td id="T_ef603_row27_col4" class="data row27 col4" >9</td>
      <td id="T_ef603_row27_col5" class="data row27 col5" >0</td>
      <td id="T_ef603_row27_col6" class="data row27 col6" >0</td>
      <td id="T_ef603_row27_col7" class="data row27 col7" >0</td>
      <td id="T_ef603_row27_col8" class="data row27 col8" >0</td>
      <td id="T_ef603_row27_col9" class="data row27 col9" >0</td>
      <td id="T_ef603_row27_col10" class="data row27 col10" >0</td>
      <td id="T_ef603_row27_col11" class="data row27 col11" >0</td>
      <td id="T_ef603_row27_col12" class="data row27 col12" >0</td>
      <td id="T_ef603_row27_col13" class="data row27 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row28" class="row_heading level0 row28" >28</th>
      <td id="T_ef603_row28_col0" class="data row28 col0" >28</td>
      <td id="T_ef603_row28_col1" class="data row28 col1" >TheDarkKnight2008.BrRip</td>
      <td id="T_ef603_row28_col2" class="data row28 col2" >5</td>
      <td id="T_ef603_row28_col3" class="data row28 col3" >6</td>
      <td id="T_ef603_row28_col4" class="data row28 col4" >18</td>
      <td id="T_ef603_row28_col5" class="data row28 col5" >9</td>
      <td id="T_ef603_row28_col6" class="data row28 col6" >5</td>
      <td id="T_ef603_row28_col7" class="data row28 col7" >6</td>
      <td id="T_ef603_row28_col8" class="data row28 col8" >10</td>
      <td id="T_ef603_row28_col9" class="data row28 col9" >0</td>
      <td id="T_ef603_row28_col10" class="data row28 col10" >0</td>
      <td id="T_ef603_row28_col11" class="data row28 col11" >0</td>
      <td id="T_ef603_row28_col12" class="data row28 col12" >0</td>
      <td id="T_ef603_row28_col13" class="data row28 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row29" class="row_heading level0 row29" >29</th>
      <td id="T_ef603_row29_col0" class="data row29 col0" >29</td>
      <td id="T_ef603_row29_col1" class="data row29 col1" >Titanic</td>
      <td id="T_ef603_row29_col2" class="data row29 col2" >15</td>
      <td id="T_ef603_row29_col3" class="data row29 col3" >18</td>
      <td id="T_ef603_row29_col4" class="data row29 col4" >0</td>
      <td id="T_ef603_row29_col5" class="data row29 col5" >24</td>
      <td id="T_ef603_row29_col6" class="data row29 col6" >0</td>
      <td id="T_ef603_row29_col7" class="data row29 col7" >11</td>
      <td id="T_ef603_row29_col8" class="data row29 col8" >11</td>
      <td id="T_ef603_row29_col9" class="data row29 col9" >0</td>
      <td id="T_ef603_row29_col10" class="data row29 col10" >4</td>
      <td id="T_ef603_row29_col11" class="data row29 col11" >0</td>
      <td id="T_ef603_row29_col12" class="data row29 col12" >0</td>
      <td id="T_ef603_row29_col13" class="data row29 col13" >Romance</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row30" class="row_heading level0 row30" >30</th>
      <td id="T_ef603_row30_col0" class="data row30 col0" >30</td>
      <td id="T_ef603_row30_col1" class="data row30 col1" >Violent.Night</td>
      <td id="T_ef603_row30_col2" class="data row30 col2" >7</td>
      <td id="T_ef603_row30_col3" class="data row30 col3" >8</td>
      <td id="T_ef603_row30_col4" class="data row30 col4" >10</td>
      <td id="T_ef603_row30_col5" class="data row30 col5" >3</td>
      <td id="T_ef603_row30_col6" class="data row30 col6" >6</td>
      <td id="T_ef603_row30_col7" class="data row30 col7" >5</td>
      <td id="T_ef603_row30_col8" class="data row30 col8" >6</td>
      <td id="T_ef603_row30_col9" class="data row30 col9" >3</td>
      <td id="T_ef603_row30_col10" class="data row30 col10" >0</td>
      <td id="T_ef603_row30_col11" class="data row30 col11" >0</td>
      <td id="T_ef603_row30_col12" class="data row30 col12" >0</td>
      <td id="T_ef603_row30_col13" class="data row30 col13" >Action</td>
    </tr>
    <tr>
      <th id="T_ef603_level0_row31" class="row_heading level0 row31" >31</th>
      <td id="T_ef603_row31_col0" class="data row31 col0" >31</td>
      <td id="T_ef603_row31_col1" class="data row31 col1" >Wanted</td>
      <td id="T_ef603_row31_col2" class="data row31 col2" >8</td>
      <td id="T_ef603_row31_col3" class="data row31 col3" >0</td>
      <td id="T_ef603_row31_col4" class="data row31 col4" >21</td>
      <td id="T_ef603_row31_col5" class="data row31 col5" >7</td>
      <td id="T_ef603_row31_col6" class="data row31 col6" >3</td>
      <td id="T_ef603_row31_col7" class="data row31 col7" >3</td>
      <td id="T_ef603_row31_col8" class="data row31 col8" >13</td>
      <td id="T_ef603_row31_col9" class="data row31 col9" >0</td>
      <td id="T_ef603_row31_col10" class="data row31 col10" >3</td>
      <td id="T_ef603_row31_col11" class="data row31 col11" >24</td>
      <td id="T_ef603_row31_col12" class="data row31 col12" >0</td>
      <td id="T_ef603_row31_col13" class="data row31 col13" >Action</td>
    </tr>
  </tbody>
</table>




# Split the data


```python
# split the data
headers=['god','help','kill','please','dead','love','sorry','beautiful','baby','father','bomb']
#y=train_data['genre']
#train_data = train_data.drop('genre',inplace=True,axis=1)
#print(train_data)
X=train_data.loc[:, headers].values
y=train_data.loc[:,'genre'].values
X_train, X_test, y_train, y_test = train_test_split(X,y, train_size=.80)
#print(X_train)
#print(y_train)
```

# Train the model 


```python
#scaler = StandardScaler()
#X_train = scaler.fit_transform(X_train)
#X_test = scaler.transform(X_test)
clf = tree.DecisionTreeClassifier()
clf = clf.fit(X_train, y_train)
```

# Make Predictions


```python
#y_pred = knn.predict(X_test)
print(clf.predict(X_test))
print(X_test)
```

    ['Action' 'Action' 'Action' 'Action' 'Romance' 'Romance' 'Romance']
    [[ 2  3 16  0  9  0  0  0  0  0  0]
     [ 4  4  5  4  5  0  3  0  3  0  0]
     [ 7  8 10  3  6  5  6  3  0  0  0]
     [ 3  0 11  6  0  7  8  0  0  0  0]
     [ 0  0  0  0  0  0  0  0  0  0  0]
     [22  7  4 13  0 12  9  0 11  0  0]
     [ 8  4  0  0  0  0 13  0  0  0  0]]



```python

```


```python

```


```python

```
